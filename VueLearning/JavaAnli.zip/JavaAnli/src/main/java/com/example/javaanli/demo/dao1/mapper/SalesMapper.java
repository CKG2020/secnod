package com.example.javaanli.demo.dao1.mapper;


import org.springframework.stereotype.Repository;

@Repository
public interface SalesMapper {

//     @Insert("insert into sales values")





}

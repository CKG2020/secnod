package constant;

public class Constant {
    public int port=10000;
    public static final String COMMAND="Command.%sCommand";
}
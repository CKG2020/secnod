package com.easyArch.client.constants;

public class Constants {
    /** 离线状态 */
    public static final byte OFFLINE_STATUS = 0;
    /** 在线状态 */
    public static final byte ONLINE_STATUS = 1;

}

package com.easyArch.client.ui.container;

public class IdContainer {
    public static final String RegisterView = "RegisterView";
    public static final String LoginView = "LoginView";
    public static final String MainView="MainView";
    public  static  final String FriendItem="FriendItem";




}

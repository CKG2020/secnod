package com.easyArch.client.manager;

public class Friendlogin {
}

package com.easyArch.client.handler;

import com.easeArch.common.handler.Handler;

public class SendHandler implements Handler {


    @Override
    public Object handler(Object object) {
        return null;
    }
}

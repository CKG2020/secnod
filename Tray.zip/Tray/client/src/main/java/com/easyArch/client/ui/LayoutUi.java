package com.easyArch.client.ui;

public class LayoutUi {
    /**
     * 登录界面
     */
    public static final String LoginView = "login/xml/login.fxml";
    /**
     * 注册界面
     */
    public static final String RegisterView = "register/xml/register.fxml";
    /**
     * 主界面
     */
    public static final String MainView = "main/xml/main.fxml";

    public static final String  FriendItem="main/xml/friendItem.fxml";
}

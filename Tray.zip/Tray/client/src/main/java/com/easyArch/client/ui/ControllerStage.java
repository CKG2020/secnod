package com.easyArch.client.ui;

import javafx.stage.Stage;

public interface ControllerStage {
    Stage getStage();
    Boolean setStage();
}

//package com.test;
//
//import com.easyArch.server.netty.TrayNettyServer;
//
//import java.io.IOException;
//
//public class TestNettyServer {
//    public static void main(String[] args) throws IOException {
//        TrayNettyServer trayNettyServer=new TrayNettyServer();
//        trayNettyServer.connect();
//    }
//}

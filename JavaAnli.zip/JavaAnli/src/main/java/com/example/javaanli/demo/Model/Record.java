package com.example.javaanli.demo.Model;

public class Record {

    private int id;
    private String stu_number;
    private String stu_name;
    private String stu_class;
    private String qingjia_time;
    private String satrt_time;
    private String end_time;
    private String qingjia_reason;
    private String class_tea_status;
    private  String tea_sp_time;
    private String tea_restore;



}

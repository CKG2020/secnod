package com.example.javaanli.demo.component;

public class Test {


    public static void main(String[] args) {

        String a ="null";
        System.out.println(a.length());

    }
}

import redis.clients.jedis.params.sortedset.ZAddParams;

public class SetParams {
    public static ZAddParams setParams() {
        return null;
    }
}

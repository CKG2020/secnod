package com.example.javaanli.demo.service1;


import org.springframework.stereotype.Service;

@Service
public class SalesServiceImpl {



}

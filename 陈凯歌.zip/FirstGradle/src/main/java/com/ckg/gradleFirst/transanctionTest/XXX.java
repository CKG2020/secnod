package com.ckg.gradleFirst.transanctionTest;

public class XXX {
}

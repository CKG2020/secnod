//package com.ckg.gradleFirst.transanctionTest;
//import com.ckg.gradleFirst.transanctionTest.service.OrdersService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = TestService1.class)
//public class TestService1 {
//    @Autowired
//    private    OrdersService ordersService;
//    @Test
//    public void testAdd() {
//        ordersService.accountMoney();
//    }
//}
